public class Main{
    public static void main(String[] args){
        MainPage.initialize();
        MainPage.loginPage();
    }
}